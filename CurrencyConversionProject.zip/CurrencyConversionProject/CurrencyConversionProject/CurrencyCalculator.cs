﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyConversionProject
{
    public class CurrencyCalculator
    {
        public CurrencyCalculator(Dollar dollarAmount, 
            CurrencyRate currencyRate)
        {
            EquivalencyResult = ValidateDollar(dollarAmount) *
                ValidateCurrencyRate(currencyRate);
        }
        public decimal EquivalencyResult { get; private set; }

        private int ValidateDollar(Dollar dollarAmount)
        {
            if (dollarAmount == null)
            {
                throw new DollarException();
            }
            return dollarAmount.DollarValue;
        }

        private decimal ValidateCurrencyRate(CurrencyRate currencyRate)
        {
            if (currencyRate == null)
            {
                throw new CurrencyRateException(); 
            }
            return currencyRate.Rate;
        }

    }
}
