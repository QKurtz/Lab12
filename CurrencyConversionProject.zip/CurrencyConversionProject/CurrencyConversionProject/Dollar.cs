﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyConversionProject
{
    public class Dollar
    {
        public Dollar(int value)
        {
            DollarValue = value;
            DollarName = ToString();
        }
        public string DollarName { get; private set; }
        public int DollarValue { get; private set; }

        public override string ToString()
        {
            return DollarValue.ToString("N0").PadLeft(3);
        }

        public static Object[] GetDollarsList()
        {
            List<object> dollarsList = new List<object>(new Dollar[]
            {
                new Dollar(1), new Dollar(5), new Dollar(10),
                new Dollar(20), new Dollar(50), new Dollar(100)
            });
            return dollarsList.ToArray();
        }
    }
}
