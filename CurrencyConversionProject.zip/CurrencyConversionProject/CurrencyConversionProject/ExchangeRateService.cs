﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace CurrencyConversionProject
{
    public class ExchangeRateService
    {
        public ExchangeRateService(string url)
        {
            Url = url;
        }

        public string Url { get; private set; }

        public T DeserializeJsonData<T>() where T : new()
        {
            using (WebClient webClient = new WebClient())
            {
                try
                {
                    string jsonData = webClient.DownloadString(Url);
                    return !string.IsNullOrEmpty(jsonData) 
                        ? JsonConvert.DeserializeObject<T>(jsonData) 
                        : new T();

                }
                catch (Exception)
                {
                    throw;
                }
            }
        }
    }
}
