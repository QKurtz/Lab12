﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CurrencyConversionProject
{
    public partial class CurrencyCalculatorForm : Form
    {
        private Dollar dollarAmount = null;
        private CurrencyRate currencyRate = null;
        private const string EXCHANGE_RATE_URL = 
            "https://openexchangerates.org/api/latest.json?app_id=883cc1e6e644400186063be74d1c1097";
        private const string CURRENCY_NAME_URL =
            "https://openexchangerates.org/api/currencies.json?app_id=883cc1e6e644400186063be74d1c1097";
        public CurrencyCalculatorForm()
        {
            InitializeComponent();
        }

        private void CurrencyCalculatorForm_Load(object sender, EventArgs e)
        {
            try
            {
                //use this in second project for dictionary
                ExchangeRateService exchangeRate = 
                    new ExchangeRateService(EXCHANGE_RATE_URL);
                CountryCodesToRates countryCodesToRate = 
                    exchangeRate.DeserializeJsonData<CountryCodesToRates>();

                //dictionary with currency code and currency name
                ExchangeRateService currencyName =
                    new ExchangeRateService(CURRENCY_NAME_URL);
                CountryCodesToNames countryCodesToName =
                    currencyName.DeserializeJsonData<CountryCodesToNames>();
                //countryCodesToNames.CountryName.ToString();
                ////public Dictionary<string, decimal> Rates { get; set; 
                //CompositeDictionary(countryCodesToRate.Rates, countryCodesToNames.Base);
                PopulateListView(countryCodesToRate.Rates);

                //CompositeDictionary(countryCodesToName.CountryName);
                dollarListBox.Items.AddRange(Dollar.GetDollarsList());

            }
            catch (Exception theException)
            {
                MessageBox.Show(theException.Message);
            }          
        }

        private void CompositeDictionary(Dictionary<string, string> outputDictionary)
        {
            foreach (KeyValuePair<string, string> pair in outputDictionary)
            {
                ListViewItem item = new ListViewItem(pair.Key);
                item.SubItems.Add(pair.Value);
                currencyListView.Items.Add(item);
            }
        }

        private void PopulateListView(Dictionary<string, decimal> ratesDictionary)
        {
            foreach (KeyValuePair<string, decimal> pair in ratesDictionary)
            {
                ListViewItem item = new ListViewItem(pair.Key);
                item.SubItems.Add(pair.Value.ToString("N"));
                currencyListView.Items.Add(item);
            }
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            try
            {
                CurrencyCalculator calculator = new CurrencyCalculator(dollarAmount, currencyRate);
                outputLabel.Text = dollarAmount.DollarName + " US Dollar(s) = " + 
                    calculator.EquivalencyResult.ToString("N") + " " + currencyRate.CurrencyName; 
            }
            catch(DollarException theException)
            {
                MessageBox.Show(theException.Message);
            }
            catch(CurrencyRateException theException)
            {
                MessageBox.Show(theException.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            dollarListBox.SetSelected(0, true);
            dollarListBox.SetSelected(0, false);
            //dollarListBox.ClearSelected();
            currencyListView.SelectedIndices.Clear();
            currencyListView.EnsureVisible(0);
            outputLabel.ResetText();
            dollarAmount = null;
            currencyRate = null;
        }

        private void currencyListView_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (currencyListView.SelectedItems.Count > 0)
            {
                int itemIndex = currencyListView.FocusedItem.Index;
                ListViewItem countryCode = currencyListView.Items[itemIndex];
                ListViewItem.ListViewSubItem rate =
                    currencyListView.Items[itemIndex].SubItems[1];
                currencyRate = new CurrencyRate(countryCode.Text, 
                    Convert.ToDecimal(rate.Text));
            }
        }

        private void dollarListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dollarListBox.SelectedIndex >= 0)
            {
                dollarAmount = (Dollar)dollarListBox.SelectedItem;
            }
        }
    }
}
