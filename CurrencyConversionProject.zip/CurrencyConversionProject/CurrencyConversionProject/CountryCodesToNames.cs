﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyConversionProject
{
    public class CountryCodesToNames
    {
        public Dictionary<string, string> CountryName { get; set; }
    }
}
