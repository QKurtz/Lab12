﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyConversionProject
{
    public class CurrencyRate
    {
        public CurrencyRate(/*string currencyCode*/string currencyName, decimal rate)
        {
            //CurrencyCode = currencyCode;
            CurrencyName = currencyName;
            Rate = rate;
        }

        //public string CurrencyCode { get; private set; }
        public string CurrencyName { get; private set; }
        public decimal Rate { get; private set; }
    }
}
