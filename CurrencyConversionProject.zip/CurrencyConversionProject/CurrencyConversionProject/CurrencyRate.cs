﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyConversionProject
{
    public class CurrencyRate
    {
        public CurrencyRate(string currencyName, decimal rate)
        {
            CurrencyName = currencyName;
            Rate = rate;
        }

        public string CurrencyName { get; private set; }
        public decimal Rate { get; private set; }
    }
}
